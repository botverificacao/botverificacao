const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'selecionar_usuario',
    async execute(interaction, client) {
        try {
            console.log('=== INICIANDO SELEÇÃO DE USUÁRIO ===');
            console.log('Interaction values:', interaction.values);
            console.log('Interaction users:', interaction.users);
            console.log('Interaction members:', interaction.members);

            // Para UserSelectMenu, usamos interaction.users
            const selectedUser = interaction.users.first();
            const requester = interaction.user;

            console.log('Usuário selecionado:', selectedUser);
            console.log('Requester:', requester.tag);

            if (!selectedUser) {
                console.log('Nenhum usuário foi selecionado');
                await interaction.reply({
                    content: 'Nenhum usuário selecionado!',
                    ephemeral: true
                });
                return;
            }

            // Verificar se não selecionou a si mesmo
            if (selectedUser.id === requester.id) {
                console.log('Usuário tentou selecionar a si mesmo');
                await interaction.reply({
                    content: 'Você não pode selecionar a si mesmo!',
                    ephemeral: true
                });
                return;
            }

            // Verificar se não selecionou um bot
            if (selectedUser.bot) {
                console.log('Usuário tentou selecionar um bot');
                await interaction.reply({
                    content: 'Você não pode selecionar um bot!',
                    ephemeral: true
                });
                return;
            }

            console.log('Usuário válido selecionado:', selectedUser.tag);

            // Registrar pedido de verificação
            client.verificationRequests.set(requester.id, Date.now());

            // Buscar configurações do sistema
            const data = client.verificationData.get(interaction.guild.id) || {};
            console.log('Dados da verificação:', data);

            // Usar canal de fichas se configurado, senão usar canal normal
            const canalId = data.canalFichas || data.canal;
            console.log('Canal ID:', canalId);

            if (!canalId) {
                console.log('Canal não configurado');
                await interaction.reply({
                    content: 'Canal de verificação não configurado!',
                    ephemeral: true
                });
                return;
            }

            const canal = await interaction.guild.channels.fetch(canalId);
            console.log('Canal encontrado:', canal?.name);

            if (!canal) {
                console.log('Canal não encontrado');
                await interaction.reply({
                    content: 'Canal de verificação não encontrado!',
                    ephemeral: true
                });
                return;
            }

            // Criar embed da ficha
            const embedFicha = new EmbedBuilder()
                .setTitle(`Verificação - ${interaction.guild.name}`)
                .setThumbnail(requester.displayAvatarURL({ dynamic: true, size: 512 }))
                .setColor('#5865F2')
                .addFields(
                    {
                        name: 'Usuário(a):',
                        value: `${requester} / ${requester.tag}\n(${requester.id})`,
                        inline: false
                    },
                    {
                        name: 'Data de criação da conta:',
                        value: `<t:${Math.floor(requester.createdTimestamp / 1000)}:F>\n(<t:${Math.floor(requester.createdTimestamp / 1000)}:R>)`,
                        inline: false
                    },
                    {
                        name: 'Informações:',
                        value: `Pergunta: Quem você conhece no servidor?\nResposta: ${selectedUser} / ${selectedUser.tag}\n(${selectedUser.id})`,
                        inline: false
                    }
                )
                .setFooter({ text: `Todos os direitos reservados: ${interaction.guild.name}` })
                .setTimestamp();

            // Botões Aceitar/Recusar
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`aceitar_${requester.id}`)
                    .setLabel('Aceitar')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`recusar_${requester.id}`)
                    .setLabel('Recusar')
                    .setStyle(ButtonStyle.Danger)
            );

            console.log('Enviando ficha para o canal...');

            // Enviar menção ao usuário selecionado
            await canal.send({
                content: `**${selectedUser}**`,
            });

            // Enviar ficha no canal correto
            await canal.send({
                embeds: [embedFicha],
                components: [row]
            });

            console.log('Ficha enviada com sucesso!');

            // Confirmar para o usuário
            await interaction.reply({
                content: `Sua ficha foi enviada com sucesso!`,
                ephemeral: true
            });

            console.log('=== SELEÇÃO CONCLUÍDA COM SUCESSO ===');

        } catch (error) {
            console.error('=== ERRO DETALHADO EM selecionarUsuario ===');
            console.error('Mensagem de erro:', error.message);
            console.error('Stack trace:', error.stack);
            console.error('Tipo de interação:', interaction.type);
            console.error('Custom ID:', interaction.customId);
            console.error('Guild ID:', interaction.guild?.id);
            console.error('=== FIM DO ERRO ===');

            await interaction.reply({
                content: 'Ocorreu um erro ao processar sua seleção. Tente novamente.',
                ephemeral: true
            });
        }
    }
};