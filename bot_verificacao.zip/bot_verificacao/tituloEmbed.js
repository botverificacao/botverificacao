module.exports = {
    name: 'tituloEmbed',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Titulo da Embed\nDigite o titulo no chat\nTempo: 2 minutos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} nao definiu o titulo a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 120000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'tituloEmbed',
            timeout: timeout
        });
    }
};