const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'recusar',
    async execute(interaction, client) {
        const userId = interaction.customId.split('_')[1];

        try {
            const member = await interaction.guild.members.fetch(userId);
            const recusador = interaction.user;

            // Buscar configurações
            const data = client.verificationData.get(interaction.guild.id) || {};
            const canalLogsId = data.canalLogs;

            // Embed de recusa - MESMO LAYOUT DAS FICHAS
            const embedRecusado = new EmbedBuilder()
                .setTitle(interaction.guild.name) // Substitui "botparadarcl" pelo nome do servidor
                .setThumbnail(recusador.displayAvatarURL({ dynamic: true, size: 512 })) // Thumbnail igual às fichas
                .setColor('#FF0000')
                .addFields({
                    name: 'Usuario(a):',
                    value: `${member} / ${member.user.tag}\n(${member.id})`,
                    inline: false
                }, {
                    name: 'Informacoes:',
                    value: `Recusado por: ${recusador} / ${recusador.tag}\n(${recusador.id})`,
                    inline: false
                })
                .setFooter({ text: `Todos os direitos reservados: ${interaction.guild.name}` });

            // Enviar no canal de logs se configurado
            if (canalLogsId) {
                const canalLogs = await interaction.guild.channels.fetch(canalLogsId);
                if (canalLogs) {
                    await canalLogs.send({ embeds: [embedRecusado] });
                }
            }


            // Mensagem temporária de recusa
            const tempMsg = await interaction.reply({
                content: 'Membro nao verificado.',
                ephemeral: true
            });

            // Atualizar mensagem original
            await interaction.message.edit({
                components: []
            });

            setTimeout(() => tempMsg.delete(), 5000);

            // Limpar pedido de verificação
            client.verificationRequests.delete(userId);

        } catch (error) {
            console.error('Erro ao processar recusa:', error);
            await interaction.reply({
                content: 'Erro ao processar a recusa!',
                ephemeral: true
            });
        }
    }
};