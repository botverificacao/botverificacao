module.exports = {
    name: 'canalLogs',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Canal de Logs\nMencione o canal no chat: #logs\nTempo: 60 segundos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} nao definiu o canal de logs a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 60000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'canalLogs',
            timeout: timeout
        });
    }
};