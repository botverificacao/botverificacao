const { ActionRowBuilder, UserSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'iniciar_verificacao',
    async execute(interaction, client) {
        // Buscar configurações do servidor
        const data = client.verificationData.get(interaction.guild.id) || {};

        console.log('Dados ao iniciar verificação:', data);

        const canalId = data.canal;

        if (!canalId) {
            const tempMsg = await interaction.reply({
                content: 'Canal de verificação não configurado! Configure o canal primeiro usando o botão "Canal".',
                ephemeral: true
            });
            setTimeout(() => tempMsg.delete(), 5000);
            return;
        }

        // Verificar se usuário já enviou pedido recentemente
        const userId = interaction.user.id;
        const lastRequest = client.verificationRequests.get(userId);
        const now = Date.now();
        const twentyFourHours = 24 * 60 * 60 * 1000;

        if (lastRequest && (now - lastRequest) < twentyFourHours) {
            const tempMsg = await interaction.reply({
                content: 'Você já enviou um pedido de verificação, aguarde para ser verificado ou espere 24h para enviar uma nova solicitação de verificação.',
                ephemeral: true
            });
            setTimeout(() => tempMsg.delete(), 10000);
            return;
        }

        // Criar User Select Menu - SEM EMOJIS
        const userSelectMenu = new ActionRowBuilder().addComponents(
            new UserSelectMenuBuilder()
                .setCustomId('selecionar_usuario_verificacao')
                .setPlaceholder('Marque quem você conhece...')
                .setMaxValues(1)
                .setMinValues(1)
        );

        const embed = new EmbedBuilder()
            .setTitle(`Verificação - ${interaction.guild.name}`) // Pega o nome do servidor
            .setDescription('Para continuar com a verificação, selecione um usuário que você conhece neste servidor.')
            .setColor('#FFA500')
            .setFooter({ text: 'Esta seleção é necessária para o processo de verificação' });

        const tempMsg = await interaction.reply({
            embeds: [embed],
            components: [userSelectMenu],
            ephemeral: true
        });
        setTimeout(() => tempMsg.delete(), 30000);
    }
};