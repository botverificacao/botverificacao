module.exports = {
    name: 'imagemEmbed',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Imagem da Embed\nCole a URL da imagem no chat\nExemplo: https://exemplo.com/imagem.jpg\nA imagem aparecerá na embed abaixo da mensagem\nTempo: 60 segundos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} não definiu a imagem a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 60000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'imagemEmbed',
            timeout: timeout
        });
    }
};