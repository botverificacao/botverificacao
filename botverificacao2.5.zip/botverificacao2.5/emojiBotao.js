module.exports = {
    name: 'emojiBotao',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Emoji do Botao\nDigite o emoji no chat\nTempo: 30 segundos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} não definiu o emoji a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 30000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'emojiBotao',
            timeout: timeout
        });
    }
};