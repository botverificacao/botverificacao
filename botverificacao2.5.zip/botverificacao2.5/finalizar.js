const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'finalizar',
    async execute(interaction, client) {
        const data = client.verificationData.get(interaction.guild.id) || {};

        console.log('📊 Dados salvos:', data);

        // Verificar se todos os campos necessários estão preenchidos
        const camposObrigatorios = ['cargo', 'canal', 'tituloEmbed', 'mensagemEmbed'];
        const camposFaltantes = camposObrigatorios.filter(campo => !data[campo]);

        if (camposFaltantes.length > 0) {
            const tempMsg = await interaction.reply({
                content: `Campos obrigatórios faltando: ${camposFaltantes.join(', ')}`,
                ephemeral: true
            });
            setTimeout(() => tempMsg.delete(), 5000);
            return;
        }

        // Enviar mensagem final no canal configurado
        const canalId = data.canal;
        const canal = await interaction.guild.channels.fetch(canalId);

        if (!canal) {
            const tempMsg = await interaction.reply({
                content: 'Canal de verificação não encontrado!',
                ephemeral: true
            });
            setTimeout(() => tempMsg.delete(), 5000);
            return;
        }

        // Criar embed final - MESMO FORMATO DO TESTE
        const embedFinal = new EmbedBuilder()
            .setTitle(data.tituloEmbed)
            .setDescription(data.mensagemEmbed)
            .setColor(data.corEmbed || '#0099ff')
            .setFooter({ text: `Todos os direitos reservados: ${interaction.guild.name}` });

        // SISTEMA DE IMAGEM - MESMO MÉTODO DO TESTE
        if (data.imagemEmbed) {
            console.log('🖼️ PROCESSANDO IMAGEM FINAL:', data.imagemEmbed);
            
            // Usar a URL EXATA como está salva (sem limpeza adicional)
            const imagemUrl = data.imagemEmbed;
            console.log('🖼️ URL USADA NA FINAL:', imagemUrl);
            
            // DEFINIR A IMAGEM EXATAMENTE COMO NO TESTE
            embedFinal.setImage(imagemUrl);
            console.log('✅ Imagem DEFINIDA no embed final');
        }

        // Botão cinza com o emoji selecionado ou padrão
        const emoji = data.emojiBotao || '✅';
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('iniciar_verificacao')
                .setLabel('Iniciar Verificação')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji(emoji)
        );

        // Enviar no canal configurado
        console.log('📤 Enviando mensagem final para o canal...');
        await canal.send({
            embeds: [embedFinal],
            components: [row]
        });

        await interaction.reply({
            content: '✅ Sistema de Verificação Configurado! Mensagem enviada no canal de verificação.',
            ephemeral: true
        });
    }
};