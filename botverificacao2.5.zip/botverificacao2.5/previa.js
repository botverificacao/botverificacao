const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'previa',
    async execute(interaction, client) {
        const data = client.verificationData.get(interaction.guild.id) || {};

        console.log('🔍 Dados na previa:', data);

        if (!data.tituloEmbed || !data.mensagemEmbed) {
            const tempMsg = await interaction.reply({
                content: 'Configure pelo menos o título e a mensagem da embed antes de ver a prévia!',
                ephemeral: true
            });
            setTimeout(() => tempMsg.delete(), 5000);
            return;
        }

        // Criar embed - MESMO FORMATO DO TESTE
        const embed = new EmbedBuilder()
            .setTitle(data.tituloEmbed || 'Título não definido')
            .setDescription(data.mensagemEmbed || 'Mensagem não definida')
            .setColor(data.corEmbed || '#0099ff')
            .setFooter({ text: `Todos os direitos reservados: ${interaction.guild.name}` });

        // SISTEMA DE IMAGEM - MESMO MÉTODO DO TESTE
        if (data.imagemEmbed) {
            console.log('🖼️ PROCESSANDO IMAGEM NA PRÉVIA:', data.imagemEmbed);
            
            // Usar a URL EXATA como está salva (sem limpeza adicional)
            const imagemUrl = data.imagemEmbed;
            console.log('🖼️ URL USADA NA PRÉVIA:', imagemUrl);
            
            // DEFINIR A IMAGEM EXATAMENTE COMO NO TESTE
            embed.setImage(imagemUrl);
            console.log('✅ Imagem DEFINIDA na prévia');
        }

        const emoji = data.emojiBotao || '✅';
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('verificar')
                .setLabel('Verificar')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji(emoji)
        );

        const tempMsg = await interaction.reply({
            content: '**PRÉVIA DA EMBED DE VERIFICAÇÃO**\nAqui está como ficará sua embed:',
            embeds: [embed],
            components: [row],
            ephemeral: true
        });
        setTimeout(() => tempMsg.delete(), 15000);
    }
};