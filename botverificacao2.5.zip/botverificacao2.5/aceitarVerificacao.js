const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'aceitar',
    async execute(interaction, client) {
        const userId = interaction.customId.split('_')[1];

        try {
            const member = await interaction.guild.members.fetch(userId);
            const aprovador = interaction.user;

            // Buscar configurações
            const data = client.verificationData.get(interaction.guild.id) || {};
            const cargoVerificadoId = data.cargo;
            const canalLogsId = data.canalLogs;

            // Aplicar cargo de verificado
            if (cargoVerificadoId) {
                try {
                    const cargo = await interaction.guild.roles.fetch(cargoVerificadoId);
                    if (cargo) {
                        await member.roles.add(cargo);
                        console.log(`Cargo ${cargo.name} adicionado para ${member.user.tag}`);
                    } else {
                        console.log('Cargo não encontrado:', cargoVerificadoId);
                    }
                } catch (error) {
                    console.error('Erro ao adicionar cargo:', error);
                }
            }

            // Embed de aceitação - MESMO LAYOUT DAS FICHAS
            const embedAceito = new EmbedBuilder()
                .setTitle(interaction.guild.name) // Substitui "botparadarcl" pelo nome do servidor
                .setThumbnail(aprovador.displayAvatarURL({ dynamic: true, size: 512 })) // Thumbnail igual às fichas
                .setColor('#00FF00')
                .addFields(
                    {
                        name: '<:mwmbro:1430086305911410798> Usuário(a):',
                        value: `${member} / ${member.user.tag}\n(\`${member.id}\`)`,
                        inline: false
                    },
                    {
                        name: '<:infomwmbro:1430086304619696129> Informações:',
                        value: `Aceito por: ${aprovador} / ${aprovador.tag}\n(\`${aprovador.id}\`)`,
                        inline: false
                    }
                )
                .setFooter({ text: `Todos os direitos reservados: ${interaction.guild.name}` });

            // Enviar no canal de logs se configurado
            if (canalLogsId) {
                const canalLogs = await interaction.guild.channels.fetch(canalLogsId);
                if (canalLogs) {
                    await canalLogs.send({ embeds: [embedAceito] });
                }
            }

            // Atualizar mensagem original
            await interaction.update({
                components: []
            });

            await interaction.followUp({
                content: `Membro verificado com sucesso!\n${member} agora é um membro verificado.`,
                ephemeral: true
            });

            // Limpar pedido de verificação
            client.verificationRequests.delete(userId);

        } catch (error) {
            console.error('Erro ao processar aceitação:', error);
            await interaction.reply({
                content: 'Erro ao processar a verificação!',
                ephemeral: true
            });
        }
    }
};