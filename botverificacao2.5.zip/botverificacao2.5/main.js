const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Collection, UserSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
require('dotenv').config();

// Função para limpar URL de imagem
function cleanImageUrl(url) {
    if (!url) return '';

    let cleanedUrl = url.trim();

    // Remover parâmetros de query para URLs comuns
    if (cleanedUrl.includes('?')) {
        cleanedUrl = cleanedUrl.split('?')[0];
    }

    // Casos especiais para serviços específicos
    if (cleanedUrl.includes('cdn.discordapp.com')) {
        // Para Discord, manter apenas o caminho básico
        cleanedUrl = cleanedUrl.split('?')[0];
    } else if (cleanedUrl.includes('imgur.com')) {
        // Para Imgur, garantir extensão .jpg se não tiver
        if (!cleanedUrl.match(/\.(jpeg|jpg|png|gif|webp)$/i)) {
            cleanedUrl += '.jpg';
        }
    }

    console.log('URL limpa:', cleanedUrl);
    return cleanedUrl;
}

// Função AGGRESSIVA para limpar URL de imagem
function cleanImageUrlAggressive(url) {
    if (!url) return '';

    let cleanedUrl = url.trim();

    console.log('🔄 URL original:', cleanedUrl);

    // Remover TODOS os parâmetros - approach agressivo
    if (cleanedUrl.includes('?')) {
        cleanedUrl = cleanedUrl.split('?')[0];
        console.log('🔧 Removidos parâmetros após ?');
    }

    // Remover tudo após & também
    if (cleanedUrl.includes('&')) {
        cleanedUrl = cleanedUrl.split('&')[0];
        console.log('🔧 Removidos parâmetros após &');
    }

    // Caso especial para Discord CDN
    if (cleanedUrl.includes('cdn.discordapp.com')) {
        // Garantir que seja apenas o caminho base
        cleanedUrl = cleanedUrl.split('?')[0].split('&')[0];
        console.log('🔧 URL do Discord limpa');
    }

    // Forçar HTTPS se for HTTP
    if (cleanedUrl.startsWith('http://')) {
        cleanedUrl = cleanedUrl.replace('http://', 'https://');
        console.log('🔧 Forçado HTTPS');
    }

    // Verificar e corrigir extensões comuns
    const hasExtension = cleanedUrl.match(/\.(jpeg|jpg|png|gif|webp|jfif)$/i);
    if (!hasExtension && cleanedUrl.includes('cdn.discordapp.com')) {
        // Para Discord, assumir que é JPG se não tiver extensão
        cleanedUrl += '.jpg';
        console.log('🔧 Adicionada extensão .jpg para Discord');
    }

    console.log('✅ URL final limpa:', cleanedUrl);
    return cleanedUrl;
}

// Função para validar URL de imagem - VERSÃO RESTRITIVA
function isValidImageUrl(url) {
    if (!url) return false;

    let testUrl = url.trim();

    // Verificar se é uma URL HTTPS válida (HTTP não é mais aceito pelo Discord)
    if (!testUrl.startsWith('https://')) {
        console.log('❌ URL não é HTTPS');
        return false;
    }

    // Serviços comprovadamente funcionais no Discord
    const allowedDomains = [
        'cdn.discordapp.com',
        'i.imgur.com',
        'images-ext-1.discordapp.net',
        'media.discordapp.net'
    ];

    const isAllowedDomain = allowedDomains.some(domain => testUrl.includes(domain));
    if (!isAllowedDomain) {
        console.log('❌ Domínio não permitido:', testUrl);
        return false;
    }

    // Verificar extensões de imagem
    const hasValidExtension = testUrl.match(/\.(jpeg|jpg|png|gif|webp)$/i) !== null;
    if (!hasValidExtension) {
        console.log('❌ Sem extensão válida:', testUrl);
        return false;
    }

    console.log('✅ URL válida:', testUrl);
    return true;
}

// Função para CORRIGIR URLs do Discord E converter formatos
function fixDiscordImageUrl(url) {
    if (!url) return '';

    let fixedUrl = url.trim();

    // Corrigir media.discordapp.net para cdn.discordapp.com
    if (fixedUrl.includes('media.discordapp.net')) {
        fixedUrl = fixedUrl.replace('media.discordapp.net', 'cdn.discordapp.com');
        console.log('🔧 URL do Discord corrigida:', fixedUrl);
    }

    // CONVERTER WEBP para PNG (Discord tem problemas com WEBP em embeds)
    if (fixedUrl.includes('.webp')) {
        fixedUrl = fixedUrl.replace('.webp', '.png');
        console.log('🔧 WEBP convertido para PNG:', fixedUrl);
    }

    return fixedUrl;
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessageReactions
    ]
});

client.commands = new Collection();
client.verificationData = new Map();
client.awaitingResponses = new Map();
client.verificationRequests = new Map();

// Carregar comandos de botão
const buttonFiles = fs.readdirSync('./').filter(file => file.endsWith('.js') && file !== 'main.js');

for (const file of buttonFiles) {
    const button = require(`./${file}`);
    client.commands.set(button.name, button);
}

client.once('ready', () => {
    console.log(`Bot ${client.user.tag} está online!`);
    console.log(`Servidores: ${client.guilds.cache.size}`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Verificar se é resposta para configuração
    if (client.awaitingResponses.has(message.author.id)) {
        const configData = client.awaitingResponses.get(message.author.id);
        const { type, timeout } = configData;

        // Clear timeout
        clearTimeout(timeout);

        try {
            let value = null;
            let displayValue = '';

            switch (type) {
                case 'cargo':
                    const roleMention = message.mentions.roles.first();
                    if (!roleMention) {
                        const tempMsg = await message.reply('Você precisa mencionar um cargo! Ex: @Verificado');
                        setTimeout(() => tempMsg.delete(), 5000);
                        return;
                    }
                    value = roleMention.id;
                    displayValue = roleMention.toString();
                    break;

                case 'canal':
                    const channelMention = message.mentions.channels.first();
                    if (!channelMention) {
                        const tempMsg = await message.reply('Você precisa mencionar um canal! Ex: #geral');
                        setTimeout(() => tempMsg.delete(), 5000);
                        return;
                    }
                    value = channelMention.id;
                    displayValue = channelMention.toString();
                    break;

                case 'canalFichas':
                    const channelFichasMention = message.mentions.channels.first();
                    if (!channelFichasMention) {
                        const tempMsg = await message.reply('Você precisa mencionar um canal! Ex: #fichas');
                        setTimeout(() => tempMsg.delete(), 5000);
                        return;
                    }
                    value = channelFichasMention.id;
                    displayValue = channelFichasMention.toString();
                    break;

                case 'canalLogs':
                    const channelLogsMention = message.mentions.channels.first();
                    if (!channelLogsMention) {
                        const tempMsg = await message.reply('Você precisa mencionar um canal! Ex: #logs');
                        setTimeout(() => tempMsg.delete(), 5000);
                        return;
                    }
                    value = channelLogsMention.id;
                    displayValue = channelLogsMention.toString();
                    break;

                case 'tituloEmbed':
                    value = message.content;
                    displayValue = message.content;
                    break;

                case 'mensagemEmbed':
                    value = message.content;
                    displayValue = message.content.length > 50 ? message.content.substring(0, 50) + '...' : message.content;
                    break;

                case 'corEmbed':
                    const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
                    if (!hexRegex.test(message.content)) {
                        const tempMsg = await message.reply('Formato de cor inválido! Use formato hexadecimal: #0099ff');
                        setTimeout(() => tempMsg.delete(), 5000);
                        return;
                    }
                    value = message.content;
                    displayValue = message.content;
                    break;

                case 'imagemEmbed':
                    // Aceitar tanto URL quanto imagem anexada
                    let imagemUrl = '';
                    let imagemDisplayValue = '';

                    // Verificar se tem anexo de imagem
                    if (message.attachments.size > 0) {
                        const attachment = message.attachments.first();
                        if (attachment.contentType && attachment.contentType.startsWith('image/')) {
                            imagemUrl = attachment.url;
                            imagemDisplayValue = `Imagem anexada: ${attachment.name}`;
                            console.log('🖼️ Imagem anexada detectada:', imagemUrl);

                            // TESTE: Mostrar a imagem anexada imediatamente
                            const testEmbed = new EmbedBuilder()
                                .setTitle('✅ IMAGEM ANEXADA CONFIGURADA')
                                .setDescription('Sua imagem foi configurada com sucesso!')
                                .setImage(imagemUrl)
                                .setColor('#00FF00');

                            const testMsg = await message.reply({
                                content: '✅ Imagem anexada configurada com sucesso!',
                                embeds: [testEmbed]
                            });

                            // Deletar mensagem de teste após 5 segundos
                            setTimeout(() => {
                                testMsg.delete().catch(console.error);
                            }, 5000);
                        } else {
                            const tempMsg = await message.reply('O arquivo anexado não é uma imagem! Anexe uma imagem ou cole uma URL.');
                            setTimeout(() => tempMsg.delete(), 5000);
                            return;
                        }
                    } else {
                        // É uma URL
                        imagemUrl = message.content.trim();

                        // Limpar URL AGGRESSIVAMENTE
                        imagemUrl = cleanImageUrlAggressive(imagemUrl);

                        // Corrigir URL do Discord se necessário
                        imagemUrl = fixDiscordImageUrl(imagemUrl);

                        // Validar URL RESTRITIVAMENTE
                        if (!isValidImageUrl(imagemUrl)) {
                            const errorMsg = await message.reply({
                                content: `❌ URL de imagem não aceita pelo Discord!\n\n**Use apenas:**\n• https://cdn.discordapp.com/...\n• https://i.imgur.com/...\n• Ou **anexe** uma imagem diretamente\n\n**URL rejeitada:** \`${imagemUrl}\``,
                                ephemeral: false
                            });
                            setTimeout(() => errorMsg.delete(), 10000);
                            return;
                        }

                        imagemDisplayValue = imagemUrl.length > 30 ? imagemUrl.substring(0, 30) + '...' : imagemUrl;

                        // TESTAR a imagem antes de aceitar
                        const testEmbed = new EmbedBuilder()
                            .setTitle('✅ IMAGEM CONFIGURADA')
                            .setDescription('Sua imagem foi configurada com sucesso!')
                            .setImage(imagemUrl)
                            .setColor('#00FF00');

                        const testMsg = await message.reply({
                            content: '✅ Imagem configurada com sucesso!',
                            embeds: [testEmbed]
                        });

                        // Deletar mensagem de teste após 5 segundos
                        setTimeout(() => {
                            testMsg.delete().catch(console.error);
                        }, 5000);
                    }

                    value = imagemUrl;
                    displayValue = imagemDisplayValue;

                    // Salvar dados
                    if (!client.verificationData.has(message.guild.id)) {
                        client.verificationData.set(message.guild.id, {});
                    }
                    const data = client.verificationData.get(message.guild.id);
                    data[type] = value;

                    console.log(`Configuração salva - ${type}:`, value);

                    // Limpar awaiting
                    client.awaitingResponses.delete(message.author.id);

                    // Deletar mensagem do usuário IMEDIATAMENTE após processar
                    setTimeout(() => {
                        message.delete().catch(console.error);
                    }, 1000);

                    break;

                case 'emojiBotao':
                    value = message.content;
                    displayValue = message.content;
                    break;
            }

            // Salvar dados (apenas para tipos que não são imagemEmbed)
            if (type !== 'imagemEmbed') {
                if (!client.verificationData.has(message.guild.id)) {
                    client.verificationData.set(message.guild.id, {});
                }
                const data = client.verificationData.get(message.guild.id);
                data[type] = value;

                console.log(`Configuração salva - ${type}:`, value);

                // Limpar awaiting
                client.awaitingResponses.delete(message.author.id);

                const successMsg = await message.reply(`Configuração salva! ${type}: ${displayValue}`);
                setTimeout(() => successMsg.delete(), 5000);

                // Deletar mensagem do usuário
                setTimeout(() => {
                    message.delete().catch(console.error);
                }, 1000);
            }

        } catch (error) {
            console.error(error);
            const errorMsg = await message.reply('Erro ao processar sua resposta!');
            setTimeout(() => errorMsg.delete(), 5000);
        }
        return;
    }

    // Comando de verificação
    if (message.content === 'vf!verificacao' || message.content === 'vf!verificação') {
        const embed = new EmbedBuilder()
            .setTitle(`${message.guild.name} | Verificação`) // Título com nome do servidor
            .setDescription(`Olá ${message.guild.name}, seja bem-vindo(a) ao painel de verificação! Logo abaixo estão os botões de configuração do sistema.\n\n` +
                `**OBS:** O **cargo do bot** precisa estar **acima do cargo de verificação**.`)
            .setColor('#0099ff')
            .setFooter({ text: `Comando executado por: ${message.author.tag}` })
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('cargo').setLabel('Cargo').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('canal').setLabel('Canal').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('canalFichas').setLabel('Canal Fichas').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('canalLogs').setLabel('Canal Logs Aprovação').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('tituloEmbed').setLabel('Título Embed').setStyle(ButtonStyle.Secondary)
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('mensagemEmbed').setLabel('Mensagem Embed').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('corEmbed').setLabel('Cor Embed').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('imagemEmbed').setLabel('Imagem Embed').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('emojiBotao').setLabel('Emoji Botão').setStyle(ButtonStyle.Secondary)
        );

        const row3 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('previa').setLabel('Prévia').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('finalizar').setLabel('Finalizar').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('resetar').setLabel('Resetar').setStyle(ButtonStyle.Danger)
        );

        await message.channel.send({ embeds: [embed], components: [row, row2, row3] });
    }

});

client.on('interactionCreate', async (interaction) => {
    // Handler para botões
    if (interaction.isButton()) {
        const command = client.commands.get(interaction.customId);

        if (!command) {
            // Verificar se é um botão de aceitar/recusar
            if (interaction.customId.startsWith('aceitar_')) {
                try {
                    const aceitarCommand = require('./aceitarVerificacao');
                    return await aceitarCommand.execute(interaction, client);
                } catch (error) {
                    console.error('Erro ao executar aceitarVerificacao:', error);
                    const tempMsg = await interaction.reply({ content: 'Erro ao processar aceitação!', ephemeral: true });
                    setTimeout(() => tempMsg.delete(), 5000);
                    return;
                }
            } else if (interaction.customId.startsWith('recusar_')) {
                try {
                    const recusarCommand = require('./recusarVerificacao');
                    return await recusarCommand.execute(interaction, client);
                } catch (error) {
                    console.error('Erro ao executar recusarVerificacao:', error);
                    const tempMsg = await interaction.reply({ content: 'Erro ao processar recusa!', ephemeral: true });
                    setTimeout(() => tempMsg.delete(), 5000);
                    return;
                }
            } else if (interaction.customId === 'iniciar_verificacao') {
                try {
                    const iniciarCommand = require('./iniciarVerificacao');
                    return await iniciarCommand.execute(interaction, client);
                } catch (error) {
                    console.error('Erro ao executar iniciarVerificacao:', error);
                    const tempMsg = await interaction.reply({ content: 'Erro ao iniciar verificação!', ephemeral: true });
                    setTimeout(() => tempMsg.delete(), 5000);
                    return;
                }
            }
            return;
        }

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(error);
            const tempMsg = await interaction.reply({ content: 'Ocorreu um erro ao executar este comando!', ephemeral: true });
            setTimeout(() => tempMsg.delete(), 5000);
        }
    }

    // Handler para User Select Menus
    if (interaction.isUserSelectMenu()) {
        console.log('UserSelectMenu detectado - Custom ID:', interaction.customId);
        if (interaction.customId === 'selecionar_usuario_verificacao') {
            try {
                const selecionarCommand = require('./selecionarUsuario');
                return await selecionarCommand.execute(interaction, client);
            } catch (error) {
                console.error('Erro no handler do UserSelectMenu:', error);
                const tempMsg = await interaction.reply({
                    content: 'Erro ao selecionar usuário! Tente novamente.',
                    ephemeral: true
                });
                setTimeout(() => tempMsg.delete(), 5000);
                return;
            }
        }
    }
});

// Handler para errors globais
process.on('unhandledRejection', (error) => {
    console.error('Erro não tratado:', error);
});

process.on('uncaughtException', (error) => {
    console.error('Exceção não capturada:', error);
});

// Iniciar bot
const token = process.env.DISCORD_TOKEN;
if (!token) {
    console.error('ERROR: DISCORD_TOKEN não encontrado no arquivo .env');
    console.log('Crie um arquivo .env com: DISCORD_TOKEN=seu_token_aqui');
    process.exit(1);
}

client.login(token).catch(error => {
    console.error('Erro ao fazer login:', error);
});