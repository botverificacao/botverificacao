module.exports = {
    name: 'cargo',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Cargo de Verificação\nMencione o cargo no chat: @Verificado\nTempo: 30 segundos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} não definiu o cargo a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 30000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'cargo',
            timeout: timeout
        });
    }
};