module.exports = {
    name: 'mensagemEmbed',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Mensagem da Embed\nDigite a mensagem no chat\nTempo: 2 minutos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} não definiu a mensagem a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 120000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'mensagemEmbed',
            timeout: timeout
        });
    }
};