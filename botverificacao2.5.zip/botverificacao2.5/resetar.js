module.exports = {
    name: 'resetar',
    async execute(interaction, client) {
        // Limpar TODOS os dados do servidor
        client.verificationData.delete(interaction.guild.id);

        // Limpar qualquer resposta pendente do usuário
        if (client.awaitingResponses.has(interaction.user.id)) {
            const configData = client.awaitingResponses.get(interaction.user.id);
            clearTimeout(configData.timeout);
            client.awaitingResponses.delete(interaction.user.id);
        }

        const tempMsg = await interaction.reply({
            content: 'Todas as configurações foram resetadas! Você pode começar do zero.',
            ephemeral: true
        });
        setTimeout(() => tempMsg.delete(), 5000);
    }
};