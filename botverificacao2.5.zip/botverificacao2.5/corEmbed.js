module.exports = {
    name: 'corEmbed',
    async execute(interaction, client) {
        const tempMsg = await interaction.reply({
            content: 'Configurar Cor da Embed\nDigite a cor no chat (formato: #0099ff)\nTempo: 60 segundos',
            ephemeral: false
        });
        setTimeout(() => tempMsg.delete(), 5000);

        const timeout = setTimeout(async() => {
            if (client.awaitingResponses.has(interaction.user.id)) {
                client.awaitingResponses.delete(interaction.user.id);
                const msg = await interaction.channel.send(`Tempo esgotado! ${interaction.user} não definiu a cor a tempo.`);
                setTimeout(() => msg.delete(), 5000);
            }
        }, 60000);

        client.awaitingResponses.set(interaction.user.id, {
            type: 'corEmbed',
            timeout: timeout
        });
    }
};